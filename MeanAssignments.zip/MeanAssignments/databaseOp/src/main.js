/*const dataAdd = require("./insertdataparam");
dataAdd.addDatawithParam(6, "Sejal");

const selectData = require("./read")
selectData.readData();

const selectData1 = require("./readwithparam");
selectData1.readwithParam({sname:"shweta"});*/



const selectdat2 = require("./readjson");
selectdat2.readwithJson({ id: "2" });









