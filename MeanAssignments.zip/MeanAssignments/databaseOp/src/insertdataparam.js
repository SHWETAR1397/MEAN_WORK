//------WITH PARAMETERS---------

let Promise = require("bluebird");
let mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

let config = require("./config");
//const Connection = require("mysql/lib/Connection");

let addDatawithParam = async (id, sname) => {

    let connection = mysql.createConnection(config.DB_DETAILS);
    await connection.connectAsync();

    let sql =
        "INSERT INTO student (id,sname) VALUES (?,?)";
    await connection.queryAsync(sql, [id, sname]);

    await connection.endAsync();

};
module.exports = { addDatawithParam };