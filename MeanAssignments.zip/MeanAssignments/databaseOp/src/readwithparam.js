const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const config = require("./config");

let readwithParam = async (input) => {
    const connection = mysql.createConnection(config.DB_DETAILS);
    await connection.connectAsync();

    let sql = "select * from  student where sname=?";
    let result = await connection.queryAsync(sql, [input.sname]);

    console.log(result);
    await connection.endAsync();
    return result;



};
module.exports = { readwithParam };
//readwithParam({ sname: "shweta" });