const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

let config = require("./config");


let readData = async () => {
    let connection = mysql.createConnection(config.DB_DETAILS);

    await connection.connectAsync();

    let sql = "SELECT * FROM student";
    let results = await connection.queryAsync(sql);

    await connection.endAsync();
    return results;

}
module.exports = { readData };
//readData();