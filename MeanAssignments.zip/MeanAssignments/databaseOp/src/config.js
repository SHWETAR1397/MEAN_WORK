let DB_DETAILS = {
    host: "localhost",
    user: "root",
    password: "cdac",
    database: "node"
};

module.exports = { DB_DETAILS }