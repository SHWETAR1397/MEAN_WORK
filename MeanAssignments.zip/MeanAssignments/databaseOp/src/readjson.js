const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const config = require("./config");

let readwithJson = async (user) => {
    try {
        const connection = mysql.createConnection(config.DB_DETAILS);
        await connection.connectAsync();

        let sql = "select * from student where id=?";
        let results = connection.queryAsync(sql, [user.id]);
        console.log(results);
        await connection.endAsync();
        return results;
    }
    catch{
        (err) => {
            console.log(err.message);
        }
    }

};

module.exports = { readwithJson };
