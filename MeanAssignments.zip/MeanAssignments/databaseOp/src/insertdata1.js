//regular way

const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

let config = require("./config");

let addData = async () => {
    const Connection = mysql.createConnection(config.DB_DETAILS);

    await Connection.connectAsync();
    let sql =
        "INSERT INTO student (id,sname) VALUES (?,?)";
    Connection.queryAsync(sql, [
        "5", "Shweta"
    ]);
    await Connection.endAsync();
};
addData();