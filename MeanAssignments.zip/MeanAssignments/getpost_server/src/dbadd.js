const Promise = require("bluebird");
const mysql = require("mysql");


Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const DB_CONFIG = {
    host: "localhost",
    user: "root",
    password: "cdac",
    database: "nodedemo1",
};

let addUser = async (input) => {
    const connection = mysql.createConnection(DB_CONFIG);
    await connection.connectAsync();
    let sql = "insert into details (id,sname,address,emailid) values (?, ?, ?, ?)";

    connecton.queryAsync(sql, [input.id, input.sname, input.address, input.emailid]);

    await connection.endAsync();
};
module.exports = { addUser };