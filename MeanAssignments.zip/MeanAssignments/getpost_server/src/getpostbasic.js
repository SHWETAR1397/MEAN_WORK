/*const express = require("express");
const app = express();

//url=http://localhost:4000
app.get("/", (req, res) => {
    res.send("i m GET request");
});

app.listen(4600);
//app.post();*/

const express = require("express");
const app = express();

// http://localhost:3000/ :: URL :: API :: REST API
// http://localhost:3000/?username=Shweta&id=12
app.get("/", (req, res) => {
    const id = req.query.id;
    const username = req.query.username;

    const json = { id: 1, title: "Shweta " };
    res.json(json);
});

// http://localhost:3000/search :: URL :: API :: REST API
app.get("/search", (req, res) => {
    const json = { id: 100, title: "I am Search API!!" };
    res.json(json);
});
app.post("/search", (req, res) => {
    const json = ({ title: "sejal" });
    res.json(json);
})
app.listen(3200);