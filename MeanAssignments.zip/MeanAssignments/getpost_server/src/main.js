const express = require("express");
const cors = require("cors");
const app = express();
app.use(cors());
app.use(express.json());

const dbadd = require("./dbadd");
app.get("/adduser", async (req, res) => {
    try {
        const input = req.query; //to read the query param
        await dbadd.addUser(input);
        res.json({ message: "successful" });

    } catch (err) {
        console.log(err.message);
        //res.json({ message: "try again" });
    }
});

app.listen(3000);