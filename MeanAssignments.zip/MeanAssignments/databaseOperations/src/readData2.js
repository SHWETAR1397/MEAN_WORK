
const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);
let db_details = {
    host: "localhost",
    user: "root",
    password: "cdac",
    database: "node"
}

const readDemo = async () => {
    const connection = mysql.createConnection(db_details);
    await connection.connectAsync();

    let sql = "SELECT * FROM STUDENT ";
    let result = await connection.queryAsync(sql);

    connection.end();

    console.log(result);
    return result;
}
readDemo();