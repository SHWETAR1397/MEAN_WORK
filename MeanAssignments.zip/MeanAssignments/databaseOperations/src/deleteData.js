const Promise = require("bluebird");
const mysqql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

let DB_DETAILS = ({
    host: "localhost",
    user: "root",
    password: "cdac",
    database: "node"
});

let readDemo = async () => {
    const connection = mysqql.createConnection(DB_DETAILS);

    await connection.connectAsync();

    let sql = "DELETE FROM student WHERE id=?";
    let result = connection.queryAsync(sql, ["1"]);

    await connection.endAsync();
    return result;

};
readDemo();