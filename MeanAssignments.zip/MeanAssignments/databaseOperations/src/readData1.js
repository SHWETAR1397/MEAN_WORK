const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

let readDemo = async () => {
    try {
        console.log("lets read db");
        const connection = mysql.createConnection({
            host: "localhost",
            user: "root",
            password: "cdac",
            database: "node"
        });
        await connection.connectAsync();
        console.log("connection created");

        await connection.endAsync();
    } catch (err) {
        console.log(err.message)
    }

};
readDemo();