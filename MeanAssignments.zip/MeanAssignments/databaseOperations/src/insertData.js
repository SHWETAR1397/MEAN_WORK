const Promise = require("bluebird");
const mysql = require("mysql");
const Connection = require("mysql/lib/Connection");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

let DB_DETAILS = ({
    host: "localhost",
    user: "root",
    password: "cdac",
    database: "node"
});
let readDemo = async () => {
    let connection = mysql.createConnection(DB_DETAILS);
    await connection.connectAsync();

    let sql = "INSERT INTO student (id,sname) VALUES (?,?)";
    let operation = await connection.queryAsync(sql, [
        "4", "sayali"
    ]);
    connection.endAsync();
    return operation;
}
readDemo();
