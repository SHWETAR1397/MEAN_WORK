const express = require("express");
const cors = require("cors")
const app = express();

app.use(cors());
app.use(express.json());


//http://localhost:3000/?username=Shweta&id=119

app.get("/a", (req, res) => {
    //const id = req.query.id;
    //const username = req.query.username;

    const json = ({ message: "world" });
    res.json(json);
});
app.listen(3001);