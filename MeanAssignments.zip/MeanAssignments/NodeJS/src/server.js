const http = require("http");

http.createServer((request, response) => {
    let json = {
        "f_name": "Shweta",
        "l_name": "Rohidas",
        "address": "Mumbai"
    }

    //response.write(JSON.stringify(json));
    //response.end();
    response.end(JSON.stringify(json));
}).listen(3000);
console.log("successful");