class Academic {
    getGraduation() {
        return "Pune University "
    }
    getCurrent() {
        return "CDAC Mumbai, kharghar"
    }

}
module.exports = Academic;