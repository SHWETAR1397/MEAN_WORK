class Main {
    static main() {
        console.log("shweta");
    }
}
Main.main();
