const Personal = require("./personal");
const Academic = require("./academic");

class Main {
    static main() {
        console.log("the execution point!!!");

        let pobj = new Personal;
        let name = pobj.getName();
        console.log(name);

        let address = pobj.getAddress();
        console.log(address);

        let contact = pobj.getContact();
        console.log(contact);


        let aobj = new Academic;
        let graduation = aobj.getGraduation();
        console.log(graduation);

        let current = aobj.getCurrent();
        console.log(current);

    }
}
Main.main();
