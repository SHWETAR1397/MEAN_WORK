class calculator {
    add(a, b) {
        return a + b;
    }
    subtract(a, b) {
        return a - b;
    }
    multiply(a, b) {
        return a * b;
    }
    divide(a, b) {
        if (b = 0) {
            console.log("undefined");
        }
        else {
            return a / b;
        }
    }
    static Main() {
        let obj = new calculator;
        let output = obj.add(2, 3);
        let output1 = obj.divide(3, 0);
        console.log(output);
        console.log(output1);
    }

}
calculator.Main();
