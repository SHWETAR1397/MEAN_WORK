class Person {
    constructor() {
        console.log("Constructor Called")
    }
    getPersonName() {
        return "Shweta Rohidas";
    }
    getPersonAddress() {
        return "Mumbai";
    }
    getPersonDetails() {
        const Name = this.getPersonName();
        const Address = this.getPersonAddress();

        return Name + " " + Address;
    }
    static Main() {
        let obj = new Person;
        const details = obj.getPersonDetails();
        console.log(details);
    }

}
Person.Main();
