class Personal {
    getName() {
        return "Shweta Rohidas ";
    }
    getAddress() {
        return "Mumbai ";
    }
    getContact() {
        return "Mobile no: 9922564761";
    }

}
module.exports = Personal;