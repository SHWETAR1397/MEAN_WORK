let submithere = function () {
    const xhr = new XMLHttpRequest();

    xhr.open("get", "http://localhost:5600/")

    xhr.onload = () => {
        console.log(xhr.responseText);
        let refjson = JSON.parse(xhr.responseText);

        domoperation(refjson);

    };
    xhr.send();
}

let domoperation = (refjson) => {
    //let input = document.querySelector("#inputid").nodeValue;

    for (i = 0; i < refjson.length; i++) {
        let item = refjson[i];
        let input = document.querySelector("#inputid").nodeValue;

        if (input === item.Id) {
            let parent = document.querySelector("#displayBox");
            let newElement = document.querySelector("#p1").cloneNode(true);

            let child1 = document.querySelector("#ch1");
            child1.innerHTML = item.fname + " " + item.lname;

            let child2 = document.querySelector("#ch2");
            child2.innerHTML = item.Id;

            let child3 = document.querySelector("#ch3");
            child3.innerHTML = item.Batch;

            newElement.appendChild(child1);
            newElement.appendChild(child2);
            newElement.appendChild(child3);

            parent.appendChild(newElement);

        }
        else {
            console.log("Invalid Student Id");
        }
    }

}