let ajaxCall = function () {

    let xhr = new XMLHttpRequest();
    xhr.open("get", "http://localhost:3300/");

    xhr.onload = () => {
        console.log(xhr.responseText);
        let refjson = JSON.parse(xhr.responseText);
        domoperation(refjson);
        //const response = xhr.responseText;
        //console.log(response);

    };
    xhr.send();
}
let domoperation = (refjson) => {
    for (let i = 0; i < refjson.length; i++) {
        let item = refjson[i];
        console.log(item);

        const parent = document.querySelector("#parent");
        const newElement = parent.cloneNode(true);

        newElement.innerHTML = item.id + " " + item.fname + " " + item.lname + " " + item.Address;
        //parent.insertBefore(newElement, parent.firstChild);
        parent.appendChild(newElement);


    }
}


