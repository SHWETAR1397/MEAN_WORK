let registerget = async () => {
    const username = document.querySelector("#username").value;
    const password = document.querySelector("#password").value;
    const emailid = document.querySelector("#emailid").value;

    let url = `http:localhost:3000/adduser?username=${username}&emailid=${emailid}&password=${password}`;

    //GET CALL
    await fetch(url);

    document.querySelector("#username").value = "";
    document.querySelector("#password").value = "";
    document.querySelector("#emailid").value = "";
};
