let mod = require("./calulator");


let total = mod.add(10, 20);
let minus = mod.subtract(10, 20);
let product = mod.multiply(10, 20);
let div = mod.divide(40, 20);

console.log(total);
console.log(minus);
console.log(product);
console.log(div);