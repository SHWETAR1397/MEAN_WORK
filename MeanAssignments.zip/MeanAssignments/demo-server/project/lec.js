let mod = require("./lec1");
console.log(mod);
let total = mod.sum(10, 20);
console.log(total);