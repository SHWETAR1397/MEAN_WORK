const http = require("http");

http.createServer((req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");

    let json = [
        { Id: "200240320111", fname: "Shruti", lname: "Jamdade", Batch: "Feb20" },
        { Id: "200240320112", fname: "Shubham", lname: "Balwade", Batch: "Feb20" },
        { Id: "200240320113", fname: "Shubham", lname: "Mahajan", Batch: "Feb20" },
        { Id: "200240320114", fname: "Shubham", lname: "Nikam", Batch: "Feb20" },
        { Id: "200240320115", fname: "Shubham", lname: "Lothe", Batch: "Feb20" },
        { Id: "200240320116", fname: "Shubham", lname: "Dashpute", Batch: "Feb20" },
        { Id: "200240320117", fname: "Shubham", lname: "Naik", Batch: "Feb20" },
        { Id: "200240320118", fname: "Shweta", lname: "Karde", Batch: "Feb20" },
        { Id: "200240320119", fname: "Shweta", lname: "Rohidas", Batch: "Feb20" }]

    res.end(JSON.stringify(json));
}).listen(5600);
