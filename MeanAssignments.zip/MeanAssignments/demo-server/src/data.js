const http = require("http");


http.createServer((request, response) => {
    response.setHeader("Access-Control-Allow-Origin", "*");
    let json = [{
        "id": "119",
        "fname": "Shweta",
        "lname": "Rohidas",
        "Address": "Mumbai"
    },
    {
        "id": "120",
        "fname": "Shruti",
        "lname": "Jamdade",
        "Address": "Pune"
    },
    {
        "id": "121",
        "fname": "Mrunali",
        "lname": "Besarkar",
        "Address": "Nagpur"
    }]
    response.end(JSON.stringify(json));
}).listen(3300);
