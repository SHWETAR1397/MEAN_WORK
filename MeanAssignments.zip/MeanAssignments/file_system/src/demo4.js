const fs = require("fs");
const promise = require("bluebird");

promise.promisifyAll(fs);
let readDemo = () => {
    const path1 = "C://Users/hp/Desktop/DAC_20/temp1.txt";
    fs.readFileAsync(path1, { encoding: "utf-8" })
        .then((data) => {
            console.log(data, "1");

            const path2 = "C://Users/hp/Desktop/DAC_20/temp1.txt";
            return fs.readFileAsync(path2, { encoding: "utf-8" })
        })
        .then((data) => {
            console.log(data, "2");

            const path3 = "C://Users/hp/Desktop/DAC_20/temp1.txt";
            return fs.readFileAsync(path3, { encoding: "utf-8" })
        })
        .then((data) => {
            console.log(data, "3");


        })
        .catch((err) => {
            console.log(err.message);
        });

}
readDemo();