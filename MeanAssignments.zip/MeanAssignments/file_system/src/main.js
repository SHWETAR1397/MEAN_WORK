const fs = require("fs");
const promise = require("bluebird");

promise.promisifyAll(fs);

let readDemo = async () => {
    const path1 = "C://Users/hp/Desktop/DAC_20/temp1.txt";
    const data1 = await fs.readFileAsync(path1, { encoding: "utf-8" })
    console.log(data1, "1");

    const path2 = "C://Users/hp/Desktop/DAC_20/temp1.txt";
    const data2 = await fs.readFileAsync(path2, { encoding: "utf-8" })
    console.log(data2, "2");

    const path3 = "C://Users/hp/Desktop/DAC_20/temp1.txt";
    const data3 = await fs.readFileAsync(path3, { encoding: "utf-8" })
    console.log(data3, "3");

    const path4 = "C://Users/hp/Desktop/DAC_20/temp1.txt";
    const data4 = await fs.readFileAsync(path4, { encoding: "utf-8" })
    console.log(data4, "4");
}
readDemo();