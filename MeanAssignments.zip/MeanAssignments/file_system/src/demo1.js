const fs = require("fs");

let readDemo = () => {
    const filepath = "C://Users/hp/Desktop/DAC_20/temp1.txt";
    fs.readFile(filepath, { encoding: "utf-8" }, (err, data) => {
        if (err) {
            return err;
        }
        console.log(data);
    });
};
readDemo();