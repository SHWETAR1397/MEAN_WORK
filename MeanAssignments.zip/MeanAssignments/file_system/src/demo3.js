const fs = require("fs");
const Promise = require("bluebird");

Promise.promisifyAll(fs);

let readDemo = () => {
    const path1 = "C://Users/hp/Desktop/DAC_20/temp1.txt";
    fs.readFileAsync(path1, { encoding: "utf-8" })
        .then((data) => {
            console.log(data)
        })
        .catch((err) => {
            console.log(err.message);
        });
};
readDemo();
