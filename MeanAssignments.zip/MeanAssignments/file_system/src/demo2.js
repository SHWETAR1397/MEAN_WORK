const fs = require("fs");
const Promise = require("bluebird");

Promise.promisifyAll(fs);

let readDemo = () => {
    const path1 = "C://Users/hp/Desktop/DAC_20/temp11.txt";//error
    const mypromise = fs.readFileAsync(path1, { encoding: "utf-8" });
    console.log(mypromise);

    //success part
    mypromise.then((data) => {
        console.log(data);
    });
    mypromise.catch((err) => {
        console.log(err.message);
    });

};
readDemo();

